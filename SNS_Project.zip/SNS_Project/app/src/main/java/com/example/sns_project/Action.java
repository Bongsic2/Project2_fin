package com.example.sns_project;

public class Action {
    static final String START_LOCATION_SERVICE="startLocationService";
    static final String STOP_LOCATION_SERVICE="stopLocationService";
    static final int LOCATION_SERVICE_ID = 175;
}
